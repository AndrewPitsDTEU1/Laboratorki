package com.example.lab34

import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.lab34.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // EventListener для зміни кольору шрифту при натисканні
        binding.textView1.setOnClickListener {
            binding.textView1.setTextColor(Color.RED)
        }
        binding.textView2.setOnClickListener {
            binding.textView2.setTextColor(Color.BLUE)
        }
        binding.textView3.setOnClickListener {
            binding.textView3.setTextColor(Color.GREEN)
        }

        // Обробка натискання на кнопку "Сховати" - ховаємо textView1
        binding.buttonHide.setOnClickListener {
            binding.textView1.visibility = View.GONE
        }

        // Обробка натискання на кнопку "Показати" - показуємо textView1
        binding.buttonShow.setOnClickListener {
            binding.textView1.visibility = View.VISIBLE
        }
    }
}
